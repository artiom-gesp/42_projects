import java.util.Iterator;
import java.util.ListIterator;
import java.lang.IllegalArgumentException;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {

    private Node first = null;
    private Node last = null;
    private int size = 0;

    private class Node
    {
        Item item;
        Node next;
        Node prev;
    }

    // construct an empty deque
    public Deque(){
        first = new Node();
        last = first;
    }

    // is the deque empty?
    public boolean isEmpty(){
        return first == null;
    }

    // return the number of items on the deque
    public int size(){
        return size;
    }

    // add the item to the front
    public void addFirst(Item item){
        if (item == null)
            throw new IllegalArgumentException("item must not be null");
        if (first != null && first.item == null)
        {
            first.item = item;
        }
        else {
            Node new_first = new Node();

            new_first.item = item;
            new_first.next = first;
            first = new_first;
            if (first.next != null)
                first.next.prev = first;
            if (last == null)
                last = first;
        }
        ++size;
    }

    // add the item to the back
    public void addLast(Item item){
        if (item == null)
            throw new IllegalArgumentException("item must not be null");
        Node new_last = new Node();
        new_last.item = item;

        if (last == null)
        {
            System.out.println("inside addlast");
            first = new_last;
            last = new_last;
        }

        last.next = new_last;
        last.next.prev = last;
        last = last.next;
        last.next = null;

        ++size;
    }

    // remove and return the item from the front
    public Item removeFirst(){
        if (first == null)
        {
            throw new java.util.NoSuchElementException("Deque already empty");
        }
        --size;
        first = first.next;
        if (first == null)
            return null;
        first.prev = null;
        return first.item;
    }

    // remove and return the item from the back
    public Item removeLast(){
        if (first == null)
        {
            throw new java.util.NoSuchElementException("Deque already empty");
        }
        if (last.prev != null) {
            last = last.prev;
            last.next = null;
        }
        else
        {
            last = null;
            first = null;
        }
        --size;
        return last != null ? last.item : null;
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator(){
        return new ListIterator();
    }

    private class ListIterator implements Iterator<Item>
    {
        private Node current = first;

        public boolean hasNext()
        {
//            System.out.println("in it : " + current.next + " " + current.item);
            return current != null;
        }
        public Item next()
        {
            Item item = current.item;
            current = current.next;
            return item;
        }
    }

    private void printDeque()
    {
        System.out.println("Printing Deque");
        for (Item item : this)
        {
            System.out.println(item);
        }
    }

    // unit testing (required)
    public static void main(String[] args){
        Deque<Character> dk = new Deque<>();

        System.out.println("Current size : " + dk.size);

        dk.addFirst('C');

        System.out.println("Current size : " + dk.size);

        dk.printDeque();

        dk.addFirst('Z');
        dk.addFirst('V');

        System.out.println("Current size : " + dk.size);

        dk.printDeque();

        System.out.println("New last: " + dk.removeLast());
        System.out.println("Current size : " + dk.size);

        dk.printDeque();

        System.out.println("New last: " + dk.removeLast());
        System.out.println("Current size : " + dk.size);
        System.out.println("New last: " + dk.removeLast());
        System.out.println("Current size : " + dk.size);

        dk.addFirst('d');

        dk.printDeque();

        dk.addLast('z');

        dk.printDeque();

        dk.addFirst('k');

        dk.printDeque();

        dk.addFirst('p');

        dk.printDeque();

        System.out.println("New first: " + dk.removeFirst());
        System.out.println("Current size : " + dk.size);

        System.out.println("New first: " + dk.removeFirst());
        System.out.println("Current size : " + dk.size);

        System.out.println("New first: " + dk.removeFirst());
        System.out.println("Current size : " + dk.size);

        System.out.println("New first: " + dk.removeFirst());
        System.out.println("Current size : " + dk.size);

        System.out.println("is empty ? : " + dk.isEmpty());

        dk.size = 12;
        System.out.println("Current size : " + dk.size);




    }
}
