import edu.princeton.cs.algs4.StdIn;

public class Permutation {
    public static void main(String[] args) {
        String s;
        if (args.length != 1)
            return;
        int stop = Integer.parseInt(args[0]);
        RandomizedQueue<String> q = new RandomizedQueue<>();
        s = StdIn.readLine();
        String[] split = s.split(" ", -1);
        for (String t : split) {
            q.enqueue(t);
        }

        if (stop <= 0 || stop > q.size())
            return;
        for (String t : q) {
            System.out.println(t);
            stop--;
        }
    }
}
