public class Solver {

    private final int dimension;
    private final Board initial;
    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial){
        if (initial == null)
            throw new IllegalArgumentException("Null argument");
        dimension = initial.dimension();
        this.initial = initial;

    }

    // is the initial board solvable? (see below)
    public boolean isSolvable(){
        // to change later
//        return initial.grid[0][0] == 0;
        return true;
    }

    // min number of moves to solve initial board
    public int moves(){
        return 9;

    }

    // sequence of boards in a shortest solution
    public Iterable<Board> solution(){
        return null;

    }

    // test client (see below)
    public static void main(String[] args){

    }

}